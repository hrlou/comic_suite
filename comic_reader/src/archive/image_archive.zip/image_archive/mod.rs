//! Image archive abstraction for zip/cbz files and folders.

use crate::prelude::*;

pub mod manifest;

#[cfg(feature = "rar")]
pub mod rar_archive;
#[cfg(feature = "rar")]
pub use rar_archive::RarImageArchive;
pub mod web_archive;
pub use web_archive::WebImageArchive;
pub mod zip_archive;
pub use zip_archive::ZipImageArchive;

pub enum ImageArchiveKind {
    Zip(ZipImageArchive),
    #[cfg(feature = "rar")]
    Rar(RarImageArchive),
}

pub struct ImageArchive {
    pub kind: ImageArchiveKind,
    pub path: PathBuf,
    pub manifest: Manifest,
    pub is_web_archive: bool,
}

pub trait ImageArchiveTrait {
    fn list_images(&self) -> Vec<String>;
    fn read_image_by_index(&mut self, page_number: usize) -> Result<Vec<u8>, AppError>;
    fn read_image_by_name(&mut self, filename: &str) -> Result<Vec<u8>, AppError>;
    fn read_manifest<P: AsRef<Path>>(path: P) -> Result<Manifest, AppError>
    where
        Self: Sized;
}

impl ImageArchive {
    pub fn total_pages(&self) -> usize {
        self.list_images().len()
    }

    pub fn manifest_mut_and_path(&mut self) -> (&mut Manifest, &Path) {
        (&mut self.manifest, self.path.as_path())
    }

    pub fn list_images(&self) -> Vec<String> {
        if self.is_web_archive {
            let external_pages = self.manifest.external_pages.clone();
            if let Some(external_pages) = external_pages{
                return external_pages.urls;
            }
        }
        match &self.kind {
            ImageArchiveKind::Zip(zip) => zip.list_images(),
            #[cfg(feature = "rar")]
            ImageArchiveKind::Rar(rar) => rar.list_images(),
        }
    }

    pub fn read_image_by_index(&mut self, page_number: usize) -> Result<Vec<u8>, AppError> {
        match &mut self.kind {
            ImageArchiveKind::Zip(zip) => zip.read_image_by_index(page_number),
            #[cfg(feature = "rar")]
            ImageArchiveKind::Rar(rar) => todo!(),
        }
    }

    pub fn read_image_by_name(&mut self, filename: &str) -> Result<Vec<u8>, AppError> {
        match &mut self.kind {
            ImageArchiveKind::Zip(zip) => zip.read_image_by_name(filename),
            #[cfg(feature = "rar")]
            ImageArchiveKind::Rar(rar) => todo!(),
        }
    }

    pub fn process<P: AsRef<Path>>(path: P) -> Result<Self, AppError> {
        let path = path.as_ref();
        if path.is_file() {
            let ext = path
                .extension()
                .and_then(|e| e.to_str())
                .unwrap_or("")
                .to_lowercase();
            match ext.as_str() {
                #[cfg(feature = "rar")]
                "cbr" | "rar" => {
                    let manifest = RarImageArchive::read_manifest(path)?;
                    Ok(ImageArchive {
                        kind: ImageArchiveKind::Rar(RarImageArchive {
                            path: path.to_path_buf(),
                            manifest: manifest.clone(),
                        }),
                        path: path.to_path_buf(),
                        manifest,
                        is_web_archive: false,
                    })
                }
                "cbz" | "zip" => {
                    let manifest = ZipImageArchive::read_manifest(path)?;
                    let is_web = manifest.meta.web_archive;
                    Ok(ImageArchive {
                        kind: ImageArchiveKind::Zip(ZipImageArchive {
                            path: path.to_path_buf(),
                            manifest: manifest.clone(),
                        }),
                        path: path.to_path_buf(),
                        manifest,
                        is_web_archive: is_web,
                    })
                }
                _ => Err(AppError::UnsupportedArchive),
            }
        } else {
            Err(AppError::UnsupportedArchive)
        }
    }
}
